$(document).ready(function() {

const cat = $('.cat');

// START СОБЫТИЕ ПРИ КЛИКЕ НА БЛОК

cat.on( "click", function() {
  $(this).toggleClass( "cat-click" );
});

// END СОБЫТИЕ ПРИ КЛИКЕ НА БЛОК

});